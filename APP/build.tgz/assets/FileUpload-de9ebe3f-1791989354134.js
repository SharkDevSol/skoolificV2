import{c as y,j as s,aa as G,an as X,z as J}from"./index-47f132bb-1791989354134.js";import{r as v,R as Q}from"./vendor-react-1c8f8aa8-1791989354134.js";import{s as p,a as c}from"./FilePreview.module-5dee54f1-1791989354134.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],ee=y("archive",Y);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=[["path",{d:"M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",key:"1tc9qg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],xe=y("camera",se);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],je=y("download",te);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]],ae=y("file",re);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ne=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]],oe=y("image",ne);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ie=[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]],ce=y("music",ie);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]],de=y("upload",le);/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]],he=y("video",pe),ue=({file:a,onRemove:u,showPreview:j=!0,progress:h,disabled:l=!1})=>{var f;const[x,N]=v.useState(null),[d,k]=v.useState(!1),I=r=>{if(r===0)return"0 Bytes";const m=1024,g=["Bytes","KB","MB","GB"],w=Math.floor(Math.log(r)/Math.log(m));return Math.round(r/Math.pow(m,w)*100)/100+" "+g[w]},D=()=>{const r=a.type;return r.startsWith("image/")?s.jsx(oe,{size:24}):r.startsWith("video/")?s.jsx(he,{size:24}):r.startsWith("audio/")?s.jsx(ce,{size:24}):r.includes("pdf")||r.includes("document")?s.jsx(X,{size:24}):r.includes("zip")||r.includes("rar")||r.includes("compressed")?s.jsx(ee,{size:24}):s.jsx(ae,{size:24})};v.useEffect(()=>{var m;const r=((m=a.type)==null?void 0:m.startsWith("image/"))||!a.type&&/\.(jpe?g|png|gif|webp|bmp|svg|heic)$/i.test(a.name||"");if(j&&r){const g=URL.createObjectURL(a);return N(g),()=>{URL.revokeObjectURL(g)}}},[a,j]);const $=()=>{k(!0)},z=r=>{r.stopPropagation(),!l&&u&&u()},E=r=>{(r.key==="Enter"||r.key===" ")&&(r.preventDefault(),z(r))},_=j&&!d&&(((f=a.type)==null?void 0:f.startsWith("image/"))||!a.type&&/\.(jpe?g|png|gif|webp|bmp|svg|heic)$/i.test(a.name||""));return s.jsxs("div",{className:`${p.filePreview} ${l?p.disabled:""}`,children:[s.jsx("div",{className:p.fileIconContainer,children:_&&x?s.jsx("img",{src:x,alt:a.name,className:p.imagePreview,onError:$}):s.jsx("div",{className:p.fileIcon,children:D()})}),s.jsxs("div",{className:p.fileInfo,children:[s.jsx("p",{className:p.fileName,title:a.name,children:a.name}),s.jsx("p",{className:p.fileSize,children:I(a.size)}),h!==void 0&&h<100&&s.jsx("div",{className:p.progressBar,children:s.jsx("div",{className:p.progressFill,style:{width:`${h}%`},role:"progressbar","aria-valuenow":h,"aria-valuemin":"0","aria-valuemax":"100","aria-label":`Upload progress: ${h}%`})})]}),s.jsx("button",{type:"button",onClick:z,onKeyDown:E,className:p.removeButton,"aria-label":`Remove ${a.name}`,disabled:l,tabIndex:0,children:s.jsx(G,{size:18})})]})},ke=({label:a,accept:u,multiple:j=!1,maxSize:h=5*1024*1024,maxFiles:l,onChange:x,onError:N,disabled:d=!1,error:k,preview:I=!0,className:D="",value:$=[],helperText:z,required:E,..._})=>{const[f,r]=v.useState($),[m,g]=v.useState(!1),[w,L]=v.useState({}),F=v.useRef(null),R=v.useRef(null);Q.useEffect(()=>{r($)},[$]);const U=`${`file-upload-${Math.random().toString(36).substr(2,9)}`}-error`,b=e=>{if(e===0)return"0 Bytes";const t=1024,n=["Bytes","KB","MB","GB"],o=Math.floor(Math.log(e)/Math.log(t));return Math.round(e/Math.pow(t,o)*100)/100+" "+n[o]},C=e=>{if(!u)return!0;const t=u.split(",").map(i=>i.trim()),n=e.type,o=e.name;return t.some(i=>{if(i.includes("*")){const M=i.split("/")[0];return n.startsWith(M+"/")}return i.startsWith(".")?o.toLowerCase().endsWith(i.toLowerCase()):n===i})},T=e=>e.size<=h,V=e=>{const t=[];return l&&f.length+e.length>l&&t.push(`Maximum ${l} file${l>1?"s":""} allowed`),e.forEach(n=>{C(n)||t.push(`${n.name}: Invalid file type`),T(n)||t.push(`${n.name}: File size exceeds ${b(h)}`)}),t},B=e=>{if(d)return;const t=Array.from(e),n=V(t);if(n.length>0){const M=n.join(", ");N&&N(M);return}const o=j?[...f,...t]:t,i=l?o.slice(0,l):o;r(i),x&&x(i),t.forEach((M,me)=>{W(M.name)})},W=e=>{let t=0;const n=setInterval(()=>{t+=10,L(o=>({...o,[e]:t})),t>=100&&(clearInterval(n),setTimeout(()=>{L(o=>{const i={...o};return delete i[e],i})},500))},100)},S=e=>{const t=e.target.files;t&&t.length>0&&B(t),e.target.value=""},q=e=>{e.preventDefault(),e.stopPropagation(),d||g(!0)},K=e=>{e.preventDefault(),e.stopPropagation(),e.target===R.current&&g(!1)},Z=e=>{e.preventDefault(),e.stopPropagation()},A=e=>{if(e.preventDefault(),e.stopPropagation(),g(!1),d)return;const t=e.dataTransfer.files;t&&t.length>0&&B(t)},H=e=>{const t=f.filter((n,o)=>o!==e);r(t),x&&x(t)},P=()=>{!d&&F.current&&F.current.click()},O=e=>{(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),P())};return s.jsxs("div",{className:`${c.fileUploadGroup} ${D}`,children:[a&&s.jsx("label",{className:c.label,children:a}),s.jsxs("div",{ref:R,className:`
          ${c.dropZone}
          ${m?c.dragging:""}
          ${d?c.disabled:""}
          ${k?c.error:""}
        `,onDragEnter:q,onDragLeave:K,onDragOver:Z,onDrop:A,onClick:P,onKeyDown:O,role:"button",tabIndex:d?-1:0,"aria-label":a||"Upload files","aria-disabled":d,"aria-describedby":k?U:void 0,children:[s.jsx("input",{ref:F,type:"file",accept:u,multiple:j,onChange:S,className:c.fileInput,disabled:d,"aria-hidden":"true",tabIndex:-1,..._}),s.jsxs("div",{className:c.dropZoneContent,children:[s.jsx(de,{className:c.uploadIcon,size:48}),s.jsx("p",{className:c.dropZoneText,children:m?s.jsx("strong",{children:"Drop files here"}):s.jsxs(s.Fragment,{children:[s.jsx("strong",{children:"Click to upload"})," or drag and drop"]})}),s.jsxs("p",{className:c.dropZoneHint,children:[u&&`Accepted formats: ${u}`,h&&` • Max size: ${b(h)}`,l&&` • Max files: ${l}`]})]})]}),k&&s.jsxs("span",{id:U,className:c.errorMessage,role:"alert","aria-live":"assertive",children:[s.jsx(J,{size:14}),k]}),f.length>0&&s.jsx("div",{className:c.fileList,children:f.map((e,t)=>s.jsx(ue,{file:e,onRemove:()=>H(t),showPreview:I,progress:w[e.name],disabled:d},`${e.name}-${t}`))})]})};export{xe as C,je as D,ke as F,de as U};
