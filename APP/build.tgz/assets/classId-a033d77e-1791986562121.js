function e(r){if(r==null||r==="")return"";const n=String(r).trim();if(n==="")return"";const t=Number(n);return!Number.isInteger(t)||t<1?n:String(t)}export{e as c};
